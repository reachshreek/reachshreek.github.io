"""
COVE 7-DOF Robot Arm — Bracket Thickness Sizing
================================================
Determines the minimum Al 6061-T6 bracket plate thickness at each link end
(L1–L6, proximal and distal faces — 12 total) via a bearing-stress check at
the actuator pilot OD.

Failure mode: the joint torque acts as a shear force at the pilot interface;
the projected bearing area (inner_OD × t) must not exceed σ_y / FOS.

Worst-case load: actuator peak output torque (stall condition) from BOM.csv.
Standalone — no imports from robot_sizing.py.
"""

from dataclasses import dataclass
from typing import List, Tuple


# Peak torques from CubeMars spec / BOM.csv — worst-case stall load
TAU_PEAK_NM = {
    "DM-J4340P-2EC": 27.0,    # [N·m]
    "DM-J10010-2EC": 150.0,   # [N·m]
}


# ─── MATERIAL & FASTENER CONSTANTS ───────────────────────────────────────────

SIGMA_Y  = 276.0   # Al 6061-T6 yield stress [MPa = N/mm²]
FOS      = 3.0     # factor of safety
STOCK_MM: List[float] = [1.5, 2, 3, 4, 5, 6, 8, 10]   # standard Al plate stock [mm]


# ─── BRACKET GEOMETRY ─────────────────────────────────────────────────────────

@dataclass
class BracketGeometry:
    name:        str    # actuator model, e.g. "DM-J4340P-2EC"
    b_mm:        float  # plate width [mm] — perpendicular to bending axis
    r_bc_mm:     float  # bolt-circle radius [mm]
    inner_OD_mm: float  # pilot boss / inner bore OD [mm] — conservative area ref


# Geometries — pilot OD / bolt-circle values are preliminary placeholders pending DM datasheet.
#   DM-J4340P-2EC output face: pilot OD / bolt-circle TBD — numeric values are prelim placeholders
#   DM-J10010-2EC body face:   pilot OD / bolt-circle TBD — numeric values are prelim placeholders
DM_J4340  = BracketGeometry(name="DM-J4340P-2EC", b_mm=48.0, r_bc_mm=13.5, inner_OD_mm=24.0)
DM_J10010 = BracketGeometry(name="DM-J10010-2EC", b_mm=85.0, r_bc_mm=42.5, inner_OD_mm=29.0)


# ─── BRACKET FACES: link → (end, joint_key, geometry) ────────────────────────
# Each link has a proximal bracket (joint driving into the link) and a distal
# bracket (joint at the far end of the link). Torque used = static torque at
# that joint face.

BRACKET_FACES: List[Tuple[str, str, str, BracketGeometry]] = [
    # (link, end,       joint_key,            geometry)
    ("L1", "proximal", "J1_base_yaw",         DM_J10010),
    ("L1", "distal",   "J2_shoulder_pitch",   DM_J4340),
    ("L2", "proximal", "J2_shoulder_pitch",   DM_J4340),
    ("L2", "distal",   "J3_shoulder_roll",    DM_J4340),
    ("L3", "proximal", "J3_shoulder_roll",    DM_J4340),
    ("L3", "distal",   "J4_elbow_pitch",      DM_J10010),
    ("L4", "proximal", "J4_elbow_pitch",      DM_J10010),
    ("L4", "distal",   "J5_wrist_roll",       DM_J4340),
    ("L5", "proximal", "J5_wrist_roll",       DM_J4340),
    ("L5", "distal",   "J6_wrist_pitch",      DM_J4340),
    ("L6", "proximal", "J6_wrist_pitch",      DM_J4340),
    ("L6", "distal",   "J7_end_yaw",          DM_J10010),
]


# ─── BEARING-STRESS THICKNESS CALCULATION ────────────────────────────────────

def size_bracket(tau_Nm: float, inner_OD_mm: float) -> dict:
    """
    Minimum bracket thickness from bearing-stress at the pilot OD.

    Model: torque τ resolved to a shear force F at the pilot radius.
           Projected bearing area A = inner_OD × t must satisfy
           σ = F / A ≤ σ_y / FOS.

    Parameters
    ----------
    tau_Nm      : joint static torque [N·m]
    inner_OD_mm : actuator pilot boss outer diameter [mm]

    Returns
    -------
    dict with keys: tau_Nm, F_N, t_req [mm], t_stock [mm]
    """
    tau_mm = tau_Nm * 1000.0                        # N·m → N·mm

    # Force at the pilot interface radius
    F = tau_mm / (inner_OD_mm / 2.0)               # N

    # Solve σ = F / (inner_OD × t) = σ_y / FOS  for t
    t_req = F * FOS / (inner_OD_mm * SIGMA_Y)      # mm
    # Equivalently: t_req = 2 × τ_mm × FOS / (inner_OD² × σ_y)

    # Round up to next standard stock size
    t_stock = next((s for s in STOCK_MM if s >= t_req), STOCK_MM[-1])

    return {
        "tau_Nm":  tau_Nm,
        "F_N":     F,
        "t_req":   t_req,
        "t_stock": t_stock,
    }


# ─── SUMMARY TABLE ────────────────────────────────────────────────────────────

def print_summary() -> None:
    """Print one row per bracket face (12 rows, 2 per link L1–L6)."""
    print()
    print("  COVE 7-DOF — BRACKET THICKNESS SIZING")
    print(f"  Al 6061-T6  σ_y={SIGMA_Y:.0f} MPa  FOS={FOS:.1f}  |  F/A bearing at pilot OD")
    print()
    print("  " + "{:<4}  {:<8}  {:<18}  {:<8}  {:>8}  {:>10}  {:>7}  {:>7}  {:>6}".format(
        "Link", "End", "Joint", "Actuator", "inner_OD", "τ_peak [N·m]", "F [N]", "t_req", "Stock"
    ))
    print("  " + "{:<4}  {:<8}  {:<18}  {:<8}  {:>8}  {:>10}  {:>7}  {:>7}  {:>6}".format(
        "────", "───────", "──────────────────", "────────",
        "────────", "──────────", "──────", "──────", "──────"
    ))

    for (link, end, joint_key, geom) in BRACKET_FACES:
        tau = TAU_PEAK_NM[geom.name]
        result = size_bracket(tau, geom.inner_OD_mm)

        print("  " + "{:<4}  {:<8}  {:<18}  {:<8}  {:>6} mm  {:>10.1f}  {:>6.0f}  {:>5.2f} mm  {:>3g} mm".format(
            link,
            end,
            joint_key,
            geom.name,
            int(geom.inner_OD_mm),
            result["tau_Nm"],
            result["F_N"],
            result["t_req"],
            result["t_stock"],
        ))

    print()
    print("  Note: DM-J10010-2EC inner_OD=29 mm is a prelim placeholder — verify against DM datasheet")
    print("  Note: bearing stress is not the critical constraint; practical minimum 2–3 mm")
    print("        recommended for bracket rigidity regardless of calculated t_req.")
    print()


# ─── MAIN ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print_summary()
