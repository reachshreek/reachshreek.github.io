# COVE Robot Arm — Roles & 3-Week Sprint to MVP

**Team:** Jack, Sam, Shane, Asheeka (Mechanical) · Steve, John (Software)
**MVP target:** End of Week 3
**Start date:** Day 1 = first day everyone is available

---

## MVP Definition

A passing MVP means **all three of these work together**:

1. At least 3 joints (J1, J2, J3) assembled on the physical arm and responding to commands
2. Software can send a joint-space move, the arm moves, and stops safely
3. E-stop cuts power within < 200 ms and software detects the event

Full 6-DOF with smooth trajectories is a **stretch goal**, not MVP.

---

## ⚠️ Lead Time Warning

> **CubeMars actuators ship from China — order Day 1, no exceptions.**
> Standard shipping is 7–14 days. Expedited (DHL) is ~5–7 days.
> Everything else (Amazon, McMaster) targets 2-day delivery.
>
> If actuators arrive late, the Week 2 assembly block slips. Order the moment
> the BOM is approved. Consider ordering a **single DM-J4340P-2EC immediately** for SW2
> to begin firmware/CAN bringup on before full kit arrives.

---

## Role Assignments

### Mechanical

| Person  | Role                            | Primary responsibility                               |
| ------- | ------------------------------- | ---------------------------------------------------- |
| Jack    | Structural Lead                 | CAD, 3D-printed housings, CF tube cutting/bonding    |
| Sam     | Dynamics Lead + Project Manager | Bearing press fits, actuator mounting, assembly      |
| Shane   | Electrical Systems Lead         | PSU wiring, CAN harness fabrication, e-stop install  |
| Asheeka | Base & Integration Lead         | Base plate, pedestal, robot stand, final integration |

### Software

| Person | Role          | Primary responsibility                               |
| ------ | ------------- | ---------------------------------------------------- |
| Steve  | IK Lead       | ROS 2 nodes, joint commander, trajectory interface   |
| John   | Firmware Lead | Teensy firmware, CAN bus, MIT-mode actuator protocol |

---

## Week 1 — Foundation (Feb 21–24)

**Goal: Order full BOM (sign-off with Ming) + basic Onshape assembly J1–J3 + software scaffolding.**

> **J4/J5 note:** wrist pitch (J4) and wrist yaw (J5) are a black-box placeholder for this week — represent as a weighted ball in CAD/URDF. Full wrist + gripper design is post-MVP.

### Shared — Day 1

- [ ] Order entire BOM; get sign-off from Ming

### Jack — Structural Lead

- [ ] Linkages between J2 and J3 in Onshape (simple sketch, metal bar linking motor faces)
- [ ] Simple heavy base plate sketch started

### Sam — Dynamics Lead

- [ ] Base mounting plate with J1 in Onshape
- [ ] Right-angle linkage to connect J1 output to J2

### Shane — Electronic Integration Lead

- Busy with midterms until Tue/Wed — no Week 1 hardware tasks
- [ ] After midterms: review BOM, flag any parts questions

### Asheeka — Base & Integration Lead

- Busy with midterms until Tue/Wed — no Week 1 hardware tasks
- [ ] After midterms: review CAD assembly from Jack/Sam

### John — Firmware Lead

- [ ] ROS 2 framework skeleton for the arm
- [ ] Placeholder joints in URDF (J1–J3 real geometry; J4/J5 as black-box ball with weights, J6 gripper omitted)

### Steve — IK Lead

- [ ] Python kinematics sim using URDF from John
- [ ] Simple forward kinematics visualization

**Week 1 checkpoint:** BOM ordered + Onshape assembly has J1–J3 + URDF stub with placeholder wrist

---

## Week 2 — Build & Stack (Days 8–14)

**Goal: Arm physically assembled J1–J3. Software stack commanding multiple joints.**

### ME1 — Structural Lead

- [ ] Finish and print J3 elbow + J4 wrist housings
- [ ] Bond CF tube end-caps; cure overnight before load testing
- [ ] Hand off printed parts to ME2 for bearing installation

### ME2 — Dynamics Lead

- [ ] Press bearings into all printed/machined housings (use arbor press — no hammers)
- [ ] Mount actuators into housings; torque all fasteners per spec
- [ ] Assemble J1–J3 sub-chain; verify no binding through full range of motion
- [ ] Mount sub-chain on base fixture with ME4

### ME3 — Electronic Integration Lead

- [ ] Route CAN + 48 V harness up through base and along arm
- [ ] Sleeve wiring bundles inside CF tube sections with PET braid
- [ ] Add XT60H connectors to each actuator power lead; test continuity
- [ ] Bench-test full harness under load (all 6 actuators powered simultaneously)

### ME4 — Base & Integration Lead

- [ ] Mount J1 actuator + bearing to final base plate
- [ ] Attach arm sub-chain from ME2; torque base bolts
- [ ] Mount Pi 5 + Teensy + PSU to DIN plate on base enclosure
- [ ] Dress and strain-relief all cables at entry points

### SW1 — IK Lead

- [ ] Implement `JointCommander` node: subscribes to `/target_joints`, publishes to Teensy via serial/CAN
- [ ] Finalize URDF for the arm (J1–J3 real geometry; J4 wrist pitch / J5 wrist yaw as placeholder mass, J6 gripper omitted until post-MVP)
- [ ] Launch `robot_state_publisher` + rviz2; visualize URDF with joint slider
- [ ] Add basic joint limit enforcement (software stops before hardware limits)

### SW2 — Firmware Lead

- [ ] Extend Teensy firmware to address all 6 actuators on CAN bus
- [ ] Implement torque-mode safety: if no heartbeat from Pi for > 100 ms → zero torque all joints
- [ ] Wire Teensy GPIO to safety relay input; E-stop triggers torque cutoff in firmware
- [ ] Expose serial command interface so SW1 can send joint targets

**Week 2 checkpoint (Day 14):** J1–J3 assembled and moving under software command. URDF visible in rviz2. E-stop tested on live arm.

---

## Week 3 — Integration & MVP Demo (Days 15–21)

**Goal: Full arm assembled, MVP demo sequence runs end-to-end.**

### ME1 — Structural Lead

- [ ] Finalize and mount J4–J6 assembly (J4 wrist pitch + J5 wrist yaw placeholder hardware; J6 gripper omitted — all post-MVP)
- [ ] Resolve any interference fits found during Week 2 testing (reprint parts as needed)
- [ ] Document final part dimensions for future reference

### ME2 — Dynamics Lead

- [ ] Complete J4–J6 actuator installation (J4/J5 placeholder; J6 gripper omitted)
- [ ] Full range-of-motion check: J1–J3 fully verified; J4/J5 placeholder — manual clearance check only
- [ ] Torque audit: re-check all fasteners after first-motion cycles

### ME3 — Electronic Integration Lead

- [ ] Final cable dress and secure (zip ties, adhesive mounts)
- [ ] Label all connectors and cable runs
- [ ] Measure and record actual current draw per joint during MVP demo sequence

### ME4 — Base & Integration Lead

- [ ] Finalize base enclosure (cover panel, cable gland entries)
- [ ] Prepare demo setup: table, camera/phone for recording, safety clear-zone markers
- [ ] Write 1-page assembly checklist for future teardown/rebuild

### SW1 — IK Lead

- [ ] Write MVP demo script: home → extend → pick pose → retract → home (joint-space waypoints)
- [ ] Add velocity scaling parameter (default 20% speed for first demos)
- [ ] Confirm `/joint_states` feedback loop is live (read back encoder positions)
- [ ] Record rviz2 + real arm side-by-side video of demo sequence

### SW2 — Firmware Lead

- [ ] Tune PD gains per joint (start conservative: Kp=10, Kd=0.5, adjust live)
- [ ] Implement position error watchdog: if |error| > 15° for > 500 ms → safe stop
- [ ] Log CAN traffic during demo for post-run review
- [ ] Write `README_firmware.md`: flash instructions, CAN ID map, safety parameters

**Week 3 checkpoint (Day 21 — MVP Demo):**

| Check                                        | Pass criteria |
| -------------------------------------------- | ------------- |
| J1–J3 move on command (J4/J5/J6 placeholder) | Yes / No      |
| Demo sequence runs without intervention      | Yes / No      |
| E-stop tested live on moving arm             | Yes / No      |
| rviz2 tracks real arm position               | Yes / No      |
| Current draw within PSU limits               | Yes / No      |

---

## Shared Responsibilities (Everyone)

- **Daily standup (15 min):** What did you do? What's blocking you? Anything others need to know?
- **Blocker escalation:** If blocked for > 2 hours on something, raise it immediately — don't wait for standup
- **Parts tracking:** ME3 owns the shared parts spreadsheet; everyone updates their row when parts arrive
- **Git:** All code in one repo; SW1 owns repo structure, but MEs can commit CAD exports and scripts

---

## Risk Register

| Risk                                       | Likelihood | Impact | Mitigation                                                        |
| ------------------------------------------ | ---------- | ------ | ----------------------------------------------------------------- |
| Actuators arrive late (>14 days)           | Medium     | High   | Order Day 1; expedite; pre-order one unit for SW2 bench work      |
| 3D printed housings don't fit bearings     | Medium     | Medium | Print test ring (bearing OD only) before printing full housing    |
| CAN bus noise causes spurious commands     | Low        | High   | Use shielded cable; terminate correctly; test before arm assembly |
| CF tube bond fails under load              | Low        | High   | Use Hysol E-120HP or similar structural epoxy; test a sample bond |
| Scope creep (trajectory planning, gripper) | High       | Medium | Freeze MVP scope at end of Week 2; new features go in a backlog   |

---

## Post-MVP Backlog (Week 4+)

- J4 (wrist pitch) + J5 (wrist yaw) mechanical design + integration
- J6 gripper mechanism design (DM-J4340P-2EC rotary → finger open/close)
- Full 6-DOF commissioning
- Cartesian space control (inverse kinematics)
- MoveIt 2 integration
- Perception (camera, object detection)
- Trajectory smoothing (S-curve / jerk limiting)
- Web dashboard / remote control
