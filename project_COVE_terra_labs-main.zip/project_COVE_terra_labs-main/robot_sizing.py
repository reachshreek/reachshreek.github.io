"""
COVE 7-DOF Robot Arm — Sizing Calculations
===========================================
Calculates:
  - Static joint torques (worst-case: arm fully extended horizontal)
  - Dynamic torque estimates (with acceleration + safety margins)
  - Motor sizing recommendations per joint
  - 3D workspace envelope visualization

Payload target: 3 kg (wine bottle)

Joint layout (J1–J7):
  J1: DM-J10010-2EC — Z-dir yaw (base)
  J2: DM-J4340P-2EC — X-dir pitch (shoulder)
  J3: DM-J4340P-2EC — Z-dir yaw (shoulder yaw)
  J4: DM-J10010-2EC — X-dir pitch (elbow)
  J5: DM-J4340P-2EC — Z-dir yaw (wrist yaw)
  J6: DM-J4340P-2EC — X-dir pitch (wrist pitch)
  J7: DM-J10010-2EC — Z-dir yaw (end)
  Gripper: DM-J4340P-2EC — not a DOF, mass only
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from dataclasses import dataclass
from typing import Tuple

# ─── ARM CONFIGURATION ────────────────────────────────────────────────────────

@dataclass
class ArmConfig:
    # ── Per-actuator masses [kg] — from CubeMars spec sheets ──────────────────
    m_dmj10010: float = 0.850   # DM-J10010-2EC (J1, J4, J7)
    m_dmj4340:  float = 0.340   # DM-J4340P-2EC (J2, J3, J5, J6, gripper)

    # ── Structural link masses [kg] — CF tube + aluminum end-caps, no actuators
    m_link_upper:   float = 0.200   # J2/J3 → J4 (split evenly: 0.100 per link)
    m_link_forearm: float = 0.150   # J4 → J5/J6 (split evenly: 0.075 per link)
    m_link_wrist:   float = 0.050   # J6/J7 → gripper tip

    m_payload: float = 3.000   # wine bottle (worst case)

    # ── Link lengths [m] — names match diagram labels L1–L6 ───────────────────
    L1:    float = 0.05   # J1→J2 bent 90° adapter (Z-rise); doesn't affect horizontal reach
    L2:    float = 0.05   # J2→J3 straight  (equal split of L_upper = 0.250 m)
    L3:    float = 0.25  # J3→J4 straight  — L2+L3 = 0.250 m
    L4:    float = 0.25   # J4→J5 straight  (equal split of L_forearm = 0.220 m)
    L5:    float = 0.05   # J5→J6 straight  — L4+L5 = 0.220 m
    L6:    float = 0.05   # J6→J7 bent 90° adapter (Z-drop); doesn't affect horizontal reach
    L_tip: float = 0.075   # J7 → gripper tip

    # ── Joint travel limits [degrees] ─────────────────────────────────────────
    J1_range: Tuple[float, float] = (-170, 170)   # base yaw (Z)
    J2_range: Tuple[float, float] = (-90,   90)   # shoulder pitch (X)
    J3_range: Tuple[float, float] = (-180, 180)   # shoulder yaw (Z)
    J4_range: Tuple[float, float] = (-140,  140)   # elbow pitch (X)
    J5_range: Tuple[float, float] = (-180, 180)   # wrist yaw (Z)
    J6_range: Tuple[float, float] = (-90,   90)   # wrist pitch (X)
    J7_range: Tuple[float, float] = (-170, 170)   # end yaw (Z)

    # ── Sizing margins ─────────────────────────────────────────────────────────
    dynamic_factor: float = 1.5
    safety_factor:  float = 2.0

    g: float = 9.81  # [m/s²]

    @property
    def total_reach(self) -> float:
        """Horizontal reach J2→J6 (L1/L6 excluded — they go in Z)."""
        return self.L2 + self.L3 + self.L4 + self.L5

    @property
    def tip_reach(self) -> float:
        """Full reach from J2 to gripper tip."""
        return self.total_reach + self.L_tip

    @property
    def design_multiplier(self) -> float:
        return self.dynamic_factor * self.safety_factor

    # Convenience aliases for gripper mass (DM-J4340P-2EC)
    @property
    def m_gripper(self) -> float:
        return self.m_dmj4340


# ─── ROTATION MATRIX HELPERS ──────────────────────────────────────────────────

def Rz(a: float) -> np.ndarray:
    """3×3 rotation matrix about Z axis (angle in radians)."""
    c, s = np.cos(a), np.sin(a)
    return np.array([[ c, -s, 0],
                     [ s,  c, 0],
                     [ 0,  0, 1]], dtype=float)

def Rx(a: float) -> np.ndarray:
    """3×3 rotation matrix about X axis (angle in radians)."""
    c, s = np.cos(a), np.sin(a)
    return np.array([[1,  0,  0],
                     [0,  c, -s],
                     [0,  s,  c]], dtype=float)

def Ry(a: float) -> np.ndarray:
    """3×3 rotation matrix about Y axis (angle in radians)."""
    c, s = np.cos(a), np.sin(a)
    return np.array([[ c, 0, s],
                     [ 0, 1, 0],
                     [-s, 0, c]], dtype=float)


def fk_tip(cfg: ArmConfig, j1, j2, j3, j4, j5, j6, j7) -> np.ndarray:
    """
    Forward kinematics for a single set of joint angles (radians).
    Returns gripper tip position as (3,) array [x, y, z].

    FK chain:
      origin
      → Rz(j1)              J1 base yaw
      → translate(0,0,L1)   L1 bent adapter: rise in Z
      → Rx(j2)              J2 shoulder pitch
      → translate(L2,0,0)   L2 straight link
      → Rz(j3)              J3 shoulder yaw
      → translate(L3,0,0)   L3 straight link
      → Rx(j4)              J4 elbow pitch
      → translate(L4,0,0)   L4 straight link
      → Rz(j5)              J5 wrist yaw
      → translate(L5,0,0)   L5 straight link
      → Rx(j6)              J6 wrist pitch
      → translate(0,0,-L6)  L6 bent adapter: drop in Z
      → Rz(j7)              J7 end yaw
      → translate(L_tip,0,0) to gripper tip
    """
    p = np.zeros(3)
    R = np.eye(3)

    # J1: base yaw
    R = R @ Rz(j1)
    # L1: Z-rise
    p = p + R @ np.array([0, 0, cfg.L1])
    # J2: shoulder pitch
    R = R @ Rx(j2)
    # L2: along X
    p = p + R @ np.array([cfg.L2, 0, 0])
    # J3: shoulder yaw
    R = R @ Rz(j3)
    # L3: along X
    p = p + R @ np.array([cfg.L3, 0, 0])
    # J4: elbow pitch
    R = R @ Rx(j4)
    # L4: along X
    p = p + R @ np.array([cfg.L4, 0, 0])
    # J5: wrist yaw
    R = R @ Rz(j5)
    # L5: along X
    p = p + R @ np.array([cfg.L5, 0, 0])
    # J6: wrist pitch
    R = R @ Rx(j6)
    # L6: Z-drop (negative Z)
    p = p + R @ np.array([0, 0, -cfg.L6])
    # J7: end yaw
    R = R @ Rz(j7)
    # L_tip: along X
    p = p + R @ np.array([cfg.L_tip, 0, 0])

    return p


# ─── FK SANITY CHECKS ─────────────────────────────────────────────────────────

def verify_fk(cfg: ArmConfig):
    """
    Run known-answer FK tests and assert correctness within 1 mm tolerance.
    """
    tol = 1e-3  # 1 mm
    tr = cfg.total_reach  # L2+L3+L4+L5
    z_net = cfg.L1 - cfg.L6  # net Z offset from L1 rise and L6 drop

    print("\n── FK Sanity Checks ──────────────────────────────────────────────────")

    # Test 1: All zeros → arm along +X
    # L1 rises in Z, L2+L3+L4+L5 extends in +X, L6 drops in Z, L_tip in +X
    # Net tip: x = tr + L_tip, y = 0, z = L1 - L6
    p = fk_tip(cfg, 0, 0, 0, 0, 0, 0, 0)
    expected = np.array([tr + cfg.L_tip, 0.0, z_net])
    err = np.linalg.norm(p - expected)
    status = "PASS" if err < tol else f"FAIL (err={err*1000:.2f} mm)"
    print(f"  All-zero angles       → tip={p}  [{status}]")
    assert err < tol, f"All-zero FK failed: got {p}, expected {expected}"

    # Test 2: J1=90° only → arm rotated to +Y
    p = fk_tip(cfg, np.pi/2, 0, 0, 0, 0, 0, 0)
    expected = np.array([0.0, tr + cfg.L_tip, z_net])
    err = np.linalg.norm(p - expected)
    status = "PASS" if err < tol else f"FAIL (err={err*1000:.2f} mm)"
    print(f"  J1=90° only           → tip={p}  [{status}]")
    assert err < tol, f"J1=90° FK failed: got {p}, expected {expected}"

    # Test 3: J2=90° only
    # Rx(90°) = [[1,0,0],[0,0,-1],[0,1,0]]: local X→world X (unchanged), local -Z→world +Y
    # Links L2..L5 and L_tip all go along local +X → still world +X.
    # L6 translate(0,0,-L6) in local -Z → world +Y: tip_y = +L6
    # Expected: (tr + L_tip, L6, L1)
    p = fk_tip(cfg, 0, np.pi/2, 0, 0, 0, 0, 0)
    expected = np.array([tr + cfg.L_tip, cfg.L6, cfg.L1])
    err = np.linalg.norm(p - expected)
    status = "PASS" if err < tol else f"FAIL (err={err*1000:.2f} mm)"
    print(f"  J2=90° only           → tip={np.round(p,4)}  [{status}]")
    assert err < tol, f"J2=90° FK failed: got {p}, expected {expected}"

    # Test 4: Reach invariant — J1 yaw shouldn't change reach distance
    r0 = np.linalg.norm(fk_tip(cfg, 0,           0, 0, 0, 0, 0, 0))
    r1 = np.linalg.norm(fk_tip(cfg, np.pi/3,     0, 0, 0, 0, 0, 0))
    r2 = np.linalg.norm(fk_tip(cfg, -np.pi/4,    0, 0, 0, 0, 0, 0))
    diff = max(abs(r0-r1), abs(r0-r2))
    status = "PASS" if diff < tol else f"FAIL (diff={diff*1000:.2f} mm)"
    print(f"  Reach invariant (J1)  → r0={r0:.4f}, r1={r1:.4f}, r2={r2:.4f}  [{status}]")
    assert diff < tol, f"Reach invariant failed: got diff={diff}"

    # Test 5: J3=90° (shoulder yaw, Z-axis)
    # Rz(90°) = [[0,-1,0],[1,0,0],[0,0,1]]: local +X → world +Y; Z column unchanged
    # L3,L4,L5 and L_tip (local +X after J3) go in world +Y
    # L6 drop (local -Z) stays in world -Z
    # Expected: x = L2, y = L3+L4+L5+L_tip, z = L1-L6
    p = fk_tip(cfg, 0, 0, np.pi/2, 0, 0, 0, 0)
    expected = np.array([cfg.L2,
                         cfg.L3 + cfg.L4 + cfg.L5 + cfg.L_tip,
                         cfg.L1 - cfg.L6])
    err = np.linalg.norm(p - expected)
    status = "PASS" if err < tol else f"FAIL (err={err*1000:.2f} mm)"
    print(f"  J3=90° only           → tip={np.round(p,4)}  [{status}]")
    assert err < tol, f"J3=90° FK failed: got {p}, expected {expected}"

    print("  All FK checks passed.\n")


# ─── STATIC TORQUE ANALYSIS ───────────────────────────────────────────────────
# Worst case: arm fully extended HORIZONTALLY (maximum moment arm per joint).

def static_torques(cfg: ArmConfig) -> dict:
    """
    Compute worst-case static gravity torques at each joint [N·m].

    Assumes arm is fully extended horizontally. Each mass is modelled at its
    approximate CoM distance from the relevant joint (measured horizontally).

    Mass inventory (distances from J2, arm fully extended horizontal):
      L2 link CoM:     L2/2                  (m_link_upper / 2 = 0.100 kg)
      J3 (shoulder yaw): L2                  (m_ak4536 = 0.340 kg)
      L3 link CoM:     L2 + L3/2             (m_link_upper / 2 = 0.100 kg)
      J4 (elbow pitch): L2 + L3              (m_ak8064 = 0.850 kg)
      L4 link CoM:     L2+L3 + L4/2          (m_link_forearm / 2 = 0.075 kg)
      J5 (wrist yaw):  L2+L3 + L4            (m_ak4536 = 0.340 kg)
      L5 link CoM:     L2+L3 + L4 + L5/2     (m_link_forearm / 2 = 0.075 kg)
      J6 (wrist pitch): L2+L3 + L4+L5        (m_ak4536 = 0.340 kg)
      J7+L6 adapter:   L2+L3 + L4+L5         (m_ak8064 = 0.850 kg, L6 goes in Z)
      Gripper:         L2+L3 + L4+L5 + L_tip (m_ak4536 = 0.340 kg)
      Payload:         L2+L3 + L4+L5 + L_tip (m_payload = 3.000 kg)
    """
    g = cfg.g
    L2, L3, L4, L5, L_tip = cfg.L2, cfg.L3, cfg.L4, cfg.L5, cfg.L_tip

    # Split structural link masses evenly between their two sub-links
    m_L2 = cfg.m_link_upper   / 2   # 0.100 kg
    m_L3 = cfg.m_link_upper   / 2   # 0.100 kg
    m_L4 = cfg.m_link_forearm / 2   # 0.075 kg
    m_L5 = cfg.m_link_forearm / 2   # 0.075 kg

    m_J3      = cfg.m_dmj4340   # shoulder yaw
    m_J4      = cfg.m_dmj10010  # elbow pitch
    m_J5      = cfg.m_dmj4340   # wrist yaw
    m_J6      = cfg.m_dmj4340   # wrist pitch
    m_J7      = cfg.m_dmj10010  # end yaw (J7 + L6 adapter treated as at same horizontal pos as J6)
    m_gripper = cfg.m_dmj4340   # gripper actuator
    m_payload = cfg.m_payload

    # ── tau_J2: shoulder pitch ── all distal masses from J2 ──────────────────
    tau_J2 = g * (
        m_L2      * (L2 / 2) +
        m_J3      * L2 +
        m_L3      * (L2 + L3 / 2) +
        m_J4      * (L2 + L3) +
        m_L4      * (L2 + L3 + L4 / 2) +
        m_J5      * (L2 + L3 + L4) +
        m_L5      * (L2 + L3 + L4 + L5 / 2) +
        m_J6      * (L2 + L3 + L4 + L5) +
        m_J7      * (L2 + L3 + L4 + L5) +    # L6 in Z → same horizontal as J6
        m_gripper * (L2 + L3 + L4 + L5 + L_tip) +
        m_payload * (L2 + L3 + L4 + L5 + L_tip)
    )

    # ── tau_J3: shoulder yaw ──────────────────────────────────────────────────
    # Pure yaw about the arm's longitudinal axis has zero gravity torque when arm is straight.
    # Conservative model: treat as worst-case = tau_J2 (sub-arm at 90° to yaw axis).
    tau_J3 = tau_J2

    # ── tau_J4: elbow pitch ── distances from J4 (= L2+L3 from J2) ───────────
    tau_J4 = g * (
        m_L4      * (L4 / 2) +
        m_J5      * L4 +
        m_L5      * (L4 + L5 / 2) +
        m_J6      * (L4 + L5) +
        m_J7      * (L4 + L5) +               # L6 in Z
        m_gripper * (L4 + L5 + L_tip) +
        m_payload * (L4 + L5 + L_tip)
    )

    # ── tau_J5: wrist yaw ─────────────────────────────────────────────────────
    # Conservative = tau_J6 (yaw worst-case = adjacent pitch torque)
    # (computed below, so we calculate J6 first and assign J5 = J6)

    # ── tau_J6: wrist pitch ── distances from J6 ─────────────────────────────
    # J7 + L6 adapter: L6 goes in Z → no horizontal moment arm from J6
    tau_J6 = g * (
        m_gripper * L_tip +
        m_payload * L_tip
    )

    tau_J5 = tau_J6  # conservative

    # ── tau_J7: end yaw ── gravity torque ≈ 0 for pure yaw ──────────────────
    # Small off-axis moment from gripper CoM offset
    gripper_com_offset = 0.05  # estimated CoM offset from yaw axis [m]
    tau_J7 = g * (m_gripper + m_payload) * gripper_com_offset

    # ── tau_J1: base yaw — inertial load ─────────────────────────────────────
    # Gravity torque is zero for symmetric yaw; critical load is inertial.
    alpha_base = np.radians(90) / 1.0   # 90°/s² moderate slew rate

    # Approximate all masses at their CoM horizontal radii from the base axis
    # (shoulder J2 is offset L1 above base, but all radii are horizontal distances)
    d_L2 = L2 / 2
    d_J3 = L2
    d_L3 = L2 + L3 / 2
    d_J4 = L2 + L3
    d_L4 = L2 + L3 + L4 / 2
    d_J5 = L2 + L3 + L4
    d_L5 = L2 + L3 + L4 + L5 / 2
    d_J6 = L2 + L3 + L4 + L5
    d_J7 = L2 + L3 + L4 + L5
    d_g  = L2 + L3 + L4 + L5 + L_tip

    I_base = (
        m_L2      * d_L2**2 +
        m_J3      * d_J3**2 +
        m_L3      * d_L3**2 +
        m_J4      * d_J4**2 +
        m_L4      * d_L4**2 +
        m_J5      * d_J5**2 +
        m_L5      * d_L5**2 +
        m_J6      * d_J6**2 +
        m_J7      * d_J7**2 +
        m_gripper * d_g**2  +
        m_payload * d_g**2
    )
    tau_J1_inertial = I_base * alpha_base

    return {
        "J1_base_yaw":       tau_J1_inertial,
        "J2_shoulder_pitch": tau_J2,
        "J3_shoulder_yaw":   tau_J3,
        "J4_elbow_pitch":    tau_J4,
        "J5_wrist_yaw":      tau_J5,
        "J6_wrist_pitch":    tau_J6,
        "J7_end_yaw":        tau_J7,
    }


# ─── DESIGN (PEAK) TORQUE ─────────────────────────────────────────────────────

def design_torques(cfg: ArmConfig) -> dict:
    """Apply dynamic + safety multipliers to get actuator peak torque targets."""
    static = static_torques(cfg)
    k = cfg.design_multiplier
    return {joint: tau * k for joint, tau in static.items()}


# ─── MOTOR SIZING ─────────────────────────────────────────────────────────────

ACTUATOR_CATALOG = {
    # Prices from store.cubemars.com / cubemars.com product pages, Feb 2026.
    "DM-J4340P-2EC": {"rated_Nm": 9.0,  "peak_Nm": 27.0,  "ratio": 40, "mass_kg": 0.340, "price_usd": 177},
    "AK60-6":   {"rated_Nm": 3.0,  "peak_Nm": 9.0,   "ratio": 6,  "mass_kg": 0.368, "price_usd": 299},
    "AK70-10":  {"rated_Nm": 8.3,  "peak_Nm": 24.8,  "ratio": 10, "mass_kg": 0.521, "price_usd": 399},
    "AK80-9":   {"rated_Nm": 9.0,  "peak_Nm": 22.0,  "ratio": 9,  "mass_kg": 0.490, "price_usd": 480},
    "AK10-9":   {"rated_Nm": 18.0, "peak_Nm": 53.0,  "ratio": 9,  "mass_kg": 0.470, "price_usd": 799},
    "DM-J10010-2EC": {"rated_Nm": 40.0, "peak_Nm": 150.0, "ratio": 10, "mass_kg": 0.850, "price_usd": 357},
}

def recommend_actuators(design_tau: dict) -> dict:
    """
    For each joint, pick the smallest catalog actuator whose peak torque
    exceeds the design torque requirement.
    """
    recommendations = {}
    for joint, tau_needed in design_tau.items():
        best = None
        candidates = [(name, spec) for name, spec in ACTUATOR_CATALOG.items()
                      if spec["peak_Nm"] >= tau_needed]
        if candidates:
            best = min(candidates, key=lambda x: x[1]["price_usd"])
        if best is None:
            best_name, best_spec = max(ACTUATOR_CATALOG.items(),
                                       key=lambda x: x[1]["peak_Nm"])
            best = (best_name, best_spec)
            flag = "  ⚠ EXCEEDS CATALOG — re-size or split load"
        else:
            flag = ""
        recommendations[joint] = {
            "required_Nm":   tau_needed,
            "actuator":      best[0],
            "peak_Nm":       best[1]["peak_Nm"],
            "rated_Nm":      best[1]["rated_Nm"],
            "ratio":         best[1]["ratio"],
            "mass_kg":       best[1]["mass_kg"],
            "price_usd":     best[1]["price_usd"],
            "margin_pct":    (best[1]["peak_Nm"] / tau_needed - 1) * 100,
            "flag":          flag,
        }
    return recommendations


# ─── WORKSPACE VISUALISATION ──────────────────────────────────────────────────

def _Rz_batch(a: np.ndarray) -> np.ndarray:
    """Batch rotation matrices about Z. a shape (N,) → output (N,3,3)."""
    N = len(a)
    c, s = np.cos(a), np.sin(a)
    R = np.zeros((N, 3, 3))
    R[:, 0, 0] = c;  R[:, 0, 1] = -s
    R[:, 1, 0] = s;  R[:, 1, 1] = c
    R[:, 2, 2] = 1
    return R

def _Rx_batch(a: np.ndarray) -> np.ndarray:
    """Batch rotation matrices about X. a shape (N,) → output (N,3,3)."""
    N = len(a)
    c, s = np.cos(a), np.sin(a)
    R = np.zeros((N, 3, 3))
    R[:, 0, 0] = 1
    R[:, 1, 1] = c;  R[:, 1, 2] = -s
    R[:, 2, 1] = s;  R[:, 2, 2] = c
    return R

def _Ry_batch(a: np.ndarray) -> np.ndarray:
    """Batch rotation matrices about Y. a shape (N,) → output (N,3,3)."""
    N = len(a)
    c, s = np.cos(a), np.sin(a)
    R = np.zeros((N, 3, 3))
    R[:, 0, 0] = c;  R[:, 0, 2] = s
    R[:, 1, 1] = 1
    R[:, 2, 0] = -s; R[:, 2, 2] = c
    return R


def compute_workspace(cfg: ArmConfig,
                      n_samples: int = 80_000) -> np.ndarray:
    """
    Monte-Carlo sample of the gripper-tip reachable workspace (full 7-DOF FK).
    All 7 joint angles are sampled uniformly from their defined ranges.
    Returns an (N, 3) array of [x, y, z] points [m].

    Vectorized: accumulates cumulative rotation matrices C1..C7 as (N,3,3)
    batches, then sums the rotated link translations in one pass — no Python loop.
    """
    rng = np.random.default_rng(seed=42)

    j1 = np.radians(rng.uniform(*cfg.J1_range, n_samples))
    j2 = np.radians(rng.uniform(*cfg.J2_range, n_samples))
    j3 = np.radians(rng.uniform(*cfg.J3_range, n_samples))
    j4 = np.radians(rng.uniform(*cfg.J4_range, n_samples))
    j5 = np.radians(rng.uniform(*cfg.J5_range, n_samples))
    j6 = np.radians(rng.uniform(*cfg.J6_range, n_samples))
    j7 = np.radians(rng.uniform(*cfg.J7_range, n_samples))

    # Cumulative rotation matrices: Cn = R_joint1 @ ... @ R_jointn
    # Shape of each: (N, 3, 3)
    C1 = _Rz_batch(j1)                         # after J1
    C2 = np.matmul(C1, _Rx_batch(j2))          # after J2
    C3 = np.matmul(C2, _Rz_batch(j3))          # after J3
    C4 = np.matmul(C3, _Rx_batch(j4))          # after J4
    C5 = np.matmul(C4, _Rz_batch(j5))          # after J5
    C6 = np.matmul(C5, _Rx_batch(j6))          # after J6
    C7 = np.matmul(C6, _Rz_batch(j7))          # after J7

    # Tip position = sum of rotated translation vectors along FK chain:
    #   C1 @ [0,0,L1]    L1 Z-rise
    #   C2 @ [L2,0,0]    L2 straight
    #   C3 @ [L3,0,0]    L3 straight
    #   C4 @ [L4,0,0]    L4 straight
    #   C5 @ [L5,0,0]    L5 straight
    #   C6 @ [0,0,-L6]   L6 Z-drop
    #   C7 @ [L_tip,0,0] to gripper tip
    def apply(R_batch, v):
        """Apply (N,3,3) batch rotation to a constant vector v→ (N,3)."""
        return np.einsum('nij,j->ni', R_batch, v)

    points = (
        apply(C1, np.array([0,         0, cfg.L1  ])) +
        apply(C2, np.array([cfg.L2,    0, 0       ])) +
        apply(C3, np.array([cfg.L3,    0, 0       ])) +
        apply(C4, np.array([cfg.L4,    0, 0       ])) +
        apply(C5, np.array([cfg.L5,    0, 0       ])) +
        apply(C6, np.array([0,         0, -cfg.L6 ])) +
        apply(C7, np.array([cfg.L_tip, 0, 0       ]))
    )
    return points


def _draw_box_3d(ax, x0, y0, z0, dx, dy, dz, color="limegreen", label=""):
    """Draw a wireframe box on a 3-D axis."""
    c = np.array([
        [x0,      y0,      z0     ],
        [x0 + dx, y0,      z0     ],
        [x0 + dx, y0 + dy, z0     ],
        [x0,      y0 + dy, z0     ],
        [x0,      y0,      z0 + dz],
        [x0 + dx, y0,      z0 + dz],
        [x0 + dx, y0 + dy, z0 + dz],
        [x0,      y0 + dy, z0 + dz],
    ])
    edges = [(0,1),(1,2),(2,3),(3,0),   # bottom
             (4,5),(5,6),(6,7),(7,4),   # top
             (0,4),(1,5),(2,6),(3,7)]   # verticals
    first = True
    for i, j in edges:
        ax.plot3D(*zip(c[i], c[j]),
                  color=color, linewidth=1.5,
                  label=label if first else None)
        first = False


def plot_workspace(cfg: ArmConfig, points: np.ndarray):
    fig = plt.figure(figsize=(20, 6))
    fig.suptitle("COVE 7-DOF Arm — Workspace Envelope", fontsize=13, fontweight="bold")

    # Wine bottle dimensions [m]: 750 ml standard bottle
    b_w, b_d, b_h = 0.08, 0.08, 0.30
    b_x0 = 0.30 - b_w / 2
    b_y0 = -b_d / 2
    b_z0 = -b_h / 2

    R = cfg.total_reach + cfg.L_tip   # max radial reach to tip
    skip = max(1, len(points) // 5000)
    z_vals = points[::skip, 2]

    # ── 3-D scatter ────────────────────────────────────────────────────────────
    ax3d = fig.add_subplot(1, 3, 1, projection="3d")
    sc = ax3d.scatter(points[::skip, 0],
                      points[::skip, 1],
                      points[::skip, 2],
                      s=0.6, alpha=0.3, c=z_vals,
                      cmap="plasma", vmin=z_vals.min(), vmax=z_vals.max())
    fig.colorbar(sc, ax=ax3d, label="Z height [m]", shrink=0.55, pad=0.12)
    ax3d.set_xlabel("X [m]"); ax3d.set_ylabel("Y [m]"); ax3d.set_zlabel("Z [m]")
    ax3d.set_title("3D Wrist-Centre Cloud\n(J1 yaw / J2 pitch / J4 elbow sampled)")

    # Max reach sphere
    u = np.linspace(0, 2 * np.pi, 30)
    v = np.linspace(0, np.pi, 20)
    ax3d.plot_surface(R * np.outer(np.cos(u), np.sin(v)),
                      R * np.outer(np.sin(u), np.sin(v)),
                      R * np.outer(np.ones_like(u), np.cos(v)),
                      alpha=0.05, color="cyan")

    _draw_box_3d(ax3d, b_x0, b_y0, b_z0, b_w, b_d, b_h,
                 color="limegreen", label="Wine bottle (80×80×300 mm)")
    ax3d.legend(fontsize=7, loc="upper left")

    # ── Top-down view (X–Y plane) ──────────────────────────────────────────────
    ax_top = fig.add_subplot(1, 3, 2)
    sc2 = ax_top.scatter(points[::skip, 0], points[::skip, 1],
                         s=0.5, alpha=0.2, c=z_vals,
                         cmap="plasma", vmin=z_vals.min(), vmax=z_vals.max())
    fig.colorbar(sc2, ax=ax_top, label="Z height [m]")
    ax_top.set_xlabel("X [m]"); ax_top.set_ylabel("Y [m]")
    ax_top.set_title("Top-Down View (X–Y)\n(colour = Z height)")
    ax_top.set_aspect("equal")
    ax_top.axhline(0, color="gray", linewidth=0.8, linestyle="--")
    ax_top.axvline(0, color="gray", linewidth=0.8, linestyle="--")
    theta_full = np.linspace(0, 2 * np.pi, 200)
    ax_top.plot(R * np.cos(theta_full), R * np.sin(theta_full),
                "r--", linewidth=1, label=f"Max tip reach = {R:.3f} m")
    from matplotlib.patches import Rectangle as _Rect
    ax_top.add_patch(_Rect((b_x0, b_y0), b_w, b_d,
                           linewidth=1.5, edgecolor="limegreen",
                           facecolor="limegreen", alpha=0.35,
                           label="Wine bottle footprint"))
    ax_top.legend(fontsize=8)

    # ── Side-view cross-section (Y ≈ 0 slice) ─────────────────────────────────
    ax2d = fig.add_subplot(1, 3, 3)
    mask = np.abs(points[:, 1]) < 0.05
    ax2d.scatter(points[mask, 0], points[mask, 2],
                 s=0.5, alpha=0.2, c="steelblue")
    ax2d.set_xlabel("X (reach) [m]"); ax2d.set_ylabel("Z (height) [m]")
    ax2d.set_title("Side View — Reachability Slice (Y ≈ 0)")
    ax2d.set_aspect("equal")
    ax2d.axhline(0, color="gray", linewidth=0.8, linestyle="--")
    ax2d.axvline(0, color="gray", linewidth=0.8, linestyle="--")
    theta_ring = np.linspace(np.radians(cfg.J2_range[0]),
                              np.radians(cfg.J2_range[1]), 120)
    ax2d.plot(R * np.cos(theta_ring), R * np.sin(theta_ring),
              "r--", linewidth=1, label=f"Max tip reach = {R:.3f} m")
    ax2d.add_patch(_Rect((b_x0, b_z0), b_w, b_h,
                         linewidth=1.5, edgecolor="limegreen",
                         facecolor="limegreen", alpha=0.35,
                         label="Wine bottle (side)"))
    ax2d.legend(fontsize=8)

    plt.tight_layout()
    plt.savefig("workspace.png", dpi=150)
    print("\nWorkspace plot saved → workspace.png")
    plt.show()


# ─── TORQUE PLOT ──────────────────────────────────────────────────────────────

def plot_torque_sweep(cfg: ArmConfig):
    """
    Show how shoulder (J2) and elbow (J4) torques vary as a function of
    arm extension angle (J2 sweep with all other joints at 0, fully extended).
    """
    angles = np.linspace(0, 90, 91)  # degrees from vertical to horizontal
    g = cfg.g
    L2, L3, L4, L5, L_tip = cfg.L2, cfg.L3, cfg.L4, cfg.L5, cfg.L_tip

    m_L2 = cfg.m_link_upper   / 2
    m_L3 = cfg.m_link_upper   / 2
    m_L4 = cfg.m_link_forearm / 2
    m_L5 = cfg.m_link_forearm / 2
    m_J3 = cfg.m_dmj4340
    m_J4 = cfg.m_dmj10010
    m_J5 = cfg.m_dmj4340
    m_J6 = cfg.m_dmj4340
    m_J7 = cfg.m_dmj10010
    m_g  = cfg.m_dmj4340
    m_p  = cfg.m_payload

    tau_J2_static = []
    tau_J4_static = []

    for angle_deg in angles:
        th = np.radians(angle_deg)   # 0 = straight up, 90 = horizontal
        cos_th = np.cos(th)

        tau2 = g * cos_th * (
            m_L2 * (L2 / 2) +
            m_J3 * L2 +
            m_L3 * (L2 + L3 / 2) +
            m_J4 * (L2 + L3) +
            m_L4 * (L2 + L3 + L4 / 2) +
            m_J5 * (L2 + L3 + L4) +
            m_L5 * (L2 + L3 + L4 + L5 / 2) +
            m_J6 * (L2 + L3 + L4 + L5) +
            m_J7 * (L2 + L3 + L4 + L5) +
            m_g  * (L2 + L3 + L4 + L5 + L_tip) +
            m_p  * (L2 + L3 + L4 + L5 + L_tip)
        )
        tau4 = g * cos_th * (
            m_L4 * (L4 / 2) +
            m_J5 * L4 +
            m_L5 * (L4 + L5 / 2) +
            m_J6 * (L4 + L5) +
            m_J7 * (L4 + L5) +
            m_g  * (L4 + L5 + L_tip) +
            m_p  * (L4 + L5 + L_tip)
        )
        tau_J2_static.append(tau2)
        tau_J4_static.append(tau4)

    k = cfg.design_multiplier
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(angles, tau_J2_static,                       "b-",  label="J2 Shoulder — static")
    ax.plot(angles, [t * k for t in tau_J2_static],      "b--", label=f"J2 Shoulder — design (×{k:.1f})")
    ax.plot(angles, tau_J4_static,                       "r-",  label="J4 Elbow    — static")
    ax.plot(angles, [t * k for t in tau_J4_static],      "r--", label=f"J4 Elbow    — design (×{k:.1f})")

    ax.set_xlabel("Shoulder angle from vertical [°]  (0=up, 90=horizontal)")
    ax.set_ylabel("Torque [N·m]")
    ax.set_title("J2 & J4 Torque vs Arm Elevation  (all other joints at 0°, fully extended)")
    ax.legend()
    ax.grid(True, alpha=0.4)
    ax.axvline(90, color="gray", linestyle=":", linewidth=1)
    ax.text(90, 2, " worst case →", color="gray", fontsize=8)

    plt.tight_layout()
    plt.savefig("torque_sweep.png", dpi=150)
    print("Torque sweep plot saved → torque_sweep.png")
    plt.show()


# ─── PRINT SUMMARY ────────────────────────────────────────────────────────────

def print_summary(cfg: ArmConfig):
    static  = static_torques(cfg)
    design  = design_torques(cfg)
    recos   = recommend_actuators(design)

    bar = "─" * 80

    print("\n" + bar)
    print("  COVE 7-DOF ARM — SIZING SUMMARY")
    print(bar)

    print(f"\n  Payload            : {cfg.m_payload:.1f} kg")
    print(f"  Link lengths       : L1={cfg.L1:.3f}  L2={cfg.L2:.3f}  L3={cfg.L3:.3f}  "
          f"L4={cfg.L4:.3f}  L5={cfg.L5:.3f}  L6={cfg.L6:.3f}  L_tip={cfg.L_tip:.3f} m")
    print(f"  Horizontal reach   : L2+L3+L4+L5 = {cfg.total_reach:.3f} m  (J2→J6; L1/L6 in Z)")
    print(f"  Tip reach          : {cfg.tip_reach:.3f} m")
    print(f"  Dynamic factor     : {cfg.dynamic_factor:.1f}×")
    print(f"  Safety factor      : {cfg.safety_factor:.1f}×")
    print(f"  Combined multiplier: {cfg.design_multiplier:.1f}×")

    print(f"\n  Actuator masses (per spec sheet):")
    print(f"    DM-J10010-2EC (J1,J4,J7) : {cfg.m_dmj10010:.3f} kg × 3 = {cfg.m_dmj10010*3:.3f} kg")
    print(f"    DM-J4340P-2EC (J2,J3,J5,J6,gripper): {cfg.m_dmj4340:.3f} kg × 5 = {cfg.m_dmj4340*5:.3f} kg")
    print(f"  Structural link masses:")
    print(f"    Upper (L2+L3)   : {cfg.m_link_upper:.3f} kg")
    print(f"    Forearm (L4+L5) : {cfg.m_link_forearm:.3f} kg")
    print(f"    Wrist (L6+tip)  : {cfg.m_link_wrist:.3f} kg")
    total_moving = (cfg.m_dmj10010 * 3 + cfg.m_dmj4340 * 5
                    + cfg.m_link_upper + cfg.m_link_forearm + cfg.m_link_wrist
                    + cfg.m_payload)
    print(f"    Payload         : {cfg.m_payload:.3f} kg")
    print(f"  ────────────────────────────────────────")
    print(f"    Total moving mass : {total_moving:.3f} kg")

    print(f"\n{'Joint':<20} {'Static [N·m]':>14} {'Design [N·m]':>14} "
          f"{'Actuator':>12} {'Peak [N·m]':>11} {'Margin':>7} {'Price':>8}")
    print(f"{'─'*20} {'─'*14} {'─'*14} {'─'*12} {'─'*11} {'─'*7} {'─'*8}")

    for joint, r in recos.items():
        static_val = static[joint]
        print(f"{joint:<20} {static_val:>14.1f} {r['required_Nm']:>14.1f} "
              f"{r['actuator']:>12} {r['peak_Nm']:>11.1f} "
              f"{r['margin_pct']:>7.0f}% {r['price_usd']:>7}$"
              f"  {r['flag']}")

    print(f"\n  Workspace (gripper tip):")
    max_reach = cfg.tip_reach
    min_reach = abs(cfg.total_reach - cfg.L_tip)
    print(f"    Max tip reach    : {max_reach:.3f} m")
    print(f"    Horizontal reach : {cfg.total_reach:.3f} m  (J2→J6)")
    print(f"    Blind-zone radius: ~{min_reach:.3f} m  (rough estimate)")
    print(f"\n{bar}\n")


# ─── MAIN ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    cfg = ArmConfig()

    # Verify FK correctness before running Monte Carlo
    verify_fk(cfg)

    print_summary(cfg)

    print("\nComputing workspace (this may take a moment)…")
    pts = compute_workspace(cfg, n_samples=80_000)
    plot_workspace(cfg, pts)

    plot_torque_sweep(cfg)
